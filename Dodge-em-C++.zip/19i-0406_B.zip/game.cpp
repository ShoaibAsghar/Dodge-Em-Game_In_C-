//============================================================================
// Name        : game.cpp
// Author      : Shoaib Asghar
// Roll No     :19I-0406
// Copyright   : (c) Reserved
// Description : Basic 2D game of Dodge 'Em...
//============================================================================

#ifndef DODGE_CPP_
#define DODGE_CPP_
#include "util.h"
#include <iostream>
#include<string>
#include<cmath> // for basic math functions such as cos, sin, sqrt
#include<time.h>
using namespace std;
 float x=480,y=100;
 float a=320,b=715;
 const int Width=10;
 const int Height=5;
 bool screen=true;
 int screen1;
 int Score=0;
 int LIVES=3;
 int wloop=1;
 int oloop=1;
 int level=1;
 int width;
 int height;
 float cx=25;   //2nd opponant car axis
 float dy=700;
 int reward_x = 40;
int reward_y = 730;
int reward_h = 20;
int reward_w = 10;
 float *_scolor=colors[BROWN];
 
 void PrintableKeys(unsigned char key, int x, int y);
 void carmove();
 void Direction();
 void carmove1();
 void Reward();
 void help();
// seed the random numbers generator by current time (see the documentation of srand for further help)...

/* Function sets canvas size (drawing area) in pixels...
 *  that is what dimensions (x and y) your game will have
 *  Note that the bottom-left coordinate has value (0,0) and top-right coordinate has value (width-1,height-1)
 * */
 
 
     // to draw Rewards
 int checkFlag[64]={1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
int arrayGold_X[64] = {35,100,170,240,585,655,720,785,35,100,170,240,585,655,720,785,35,100,170,240,585,655,720,785,35,100,170,240,585,655,720,785,
35,100,170,240,585,655,720,785,35,100,170,240,585,655,720,785,35,100,170,240,585,655,720,785,35,100,170,240,585,655,720,785,};
int arrayGold_Y[64] = {715,715,715,715,715,715,715,715,650,650,650,650,650,650,650,650,585,585,585,585,585,585,585,585,520,520,520,520,520,520,520,520,
295,295,295,295,295,295,295,295,230,230,230,230,230,230,230,230,165,165,165,165,165,165,165,165,100,100,100,100,100,100,100,100};

//FUNCTION TO DRAW 
void Reward()
{
	
    float *RewardColor = colors[BROWN];
   for(int i=0; i<64;i++)
    {
        if((arrayGold_X[i] - a)>=0 && (arrayGold_X[i] - a)<=25 && (arrayGold_Y[i]-b)>=0 && (arrayGold_Y[i]-b)<=25 && checkFlag[i] == 1)
        {
            checkFlag[i] = 0;
            Score++;
        }
    }
     for(int i=0; i<64;i++)                                    //to disapear reward
    {
        if(checkFlag[i] == 1)
        DrawRectangle(arrayGold_X[i],arrayGold_Y[i],reward_h,reward_w,RewardColor);
    }
}
 
 
 
 
 // function when cars collides
 
 bool collide=false;
 void clash()
 
 {
   if((x-a)>=-5 && (x-a)<=5&&(y-b)>=-5&&(y-b)<=5)
   {
    DrawString(405,405,"Game Over ",colors[WHITE]);
    x=480;
    y=100;
    a=320;
    b=715;
    collide=true;
    wloop=1;
    oloop=1;
    LIVES--;
    Score=0;
    for(int i=0;i<64;i++)
    {
    checkFlag[i] = 1;
    }
    
    Reward();
    }
   } 
 void gameover()
 {
        glClearColor(0/*Red Component*/, 0,	//148.0/255/*Green Component*/,
			0.0/*Blue Component*/, 0 /*Alpha component*/); // Red==Green==Blue==1 --> White Colour
	glClear (GL_COLOR_BUFFER_BIT); //Update the colors
	DrawString( 50, 800, "GAME OVER ", colors[MISTY_ROSE]);
	
  }	

  void gamewon()
  {
   
       glClearColor(0/*Red Component*/, 0,    //148.0/255/*Green Component*/,
			0.0/*Blue Component*/, 0 /*Alpha component*/); // Red==Green==Blue==1 --> White Colour
	glClear (GL_COLOR_BUFFER_BIT); //Update the colors
	DrawString( 50, 800, "YOU WON ", colors[MISTY_ROSE]);



   }
     

	
	
	
 
 void game1()
 {
      // set the background color using function glClearColor.
	// to change the background play with the red, green and blue values below.
	// Note that r, g and b values must be in the range [0,1] where 0 means dim rid and 1 means pure red and so on.

	glClearColor(0/*Red Component*/, 0,	//148.0/255/*Green Component*/,
			0.0/*Blue Component*/, 0 /*Alpha component*/); // Red==Green==Blue==1 --> White Colour
	glClear (GL_COLOR_BUFFER_BIT); //Update the colors

	// calling some functions from util.cpp file to help students

	//Square at 400,20 position

	
	
	if(collide==true)
	   {
	    wloop=1;
	    oloop=1;
	    collide=false;
	    }
	   
	 
	
	      
	 
	 //}                                  //DrawSquare( 200 , 20 ,40,colors[BROWN]); 
	//Square at 250,250 position
	//DrawSquare( 250 , 250 ,20,colors[GREEN]); 
	//Display Score
	//DrawString( 50, 800, "Score=0", colors[MISTY_ROSE]);
	//Triangle at 300, 450 position
	//DrawTriangle( 300, 450 , 340, 450 , 320 , 490, colors[MISTY_ROSE] ); 
	// Trianlge Vertices v1(300,50) , v2(500,50) , v3(400,250)
	//Circle at 50, 670 position
	//DrawCircle(50,670,10,colors[RED]);
	//Line from 550,50 to 550,480 with width 10
	//DrawLine(int x1, int y1, int x2, int y2, int lwidth, float *color)
	//DrawLine( 550 , 50 ,  550 , 480 , 10 , colors[MISTY_ROSE] );	
	
	// Drawing opponent car
	
	  
	float width = 8; 
	float height = 4;
	float* color = colors[BLUE_VIOLET]; 
	float radius = 4.0;
	DrawRoundRect(x,y,width,height,color,radius); // bottom left tyre
	DrawRoundRect(x+width*3,y,width,height,color,radius); // bottom right tyre
	DrawRoundRect(x+width*3,y+height*4,width,height,color,radius); // top right tyre
	DrawRoundRect(x,y+height*4,width,height,color,radius); // top left tyre
	DrawRoundRect(x, y+height*2, width, height, color, radius/2); // body left rect
	DrawRoundRect(x+width, y+height, width*2, height*3, color, radius/2); // body center rect
	DrawRoundRect(x+width*3, y+height*2, width, height, color, radius/2); // body right rect
	
	// Drawing player car
	      
	  width = 8; 
	 height = 4;
	  color = colors[YELLOW]; 
	 radius = 4.0;
	DrawRoundRect(a,b,width,height,color,radius); // bottom left tyre
	DrawRoundRect(a+width*3,b,width,height,color,radius); // bottom right tyre
	DrawRoundRect(a+width*3,b+height*4,width,height,color,radius); // top right tyre
	DrawRoundRect(a,b+height*4,width,height,color,radius); // top left tyre
	DrawRoundRect(a, b+height*2, width, height, color, radius/2); // body left rect
	DrawRoundRect(a+width, b+height, width*2, height*3, color, radius/2); // body center rect
	DrawRoundRect(a+width*3, b+height*2, width, height, color, radius/2); // body right rect
	

	// Drawing Arena
	int gap_turn = 120;
	int sx = 20;
	int sy = 10;
	int swidth = 800/2 - gap_turn/2; // half width
	int sheight = 10;
	float *scolor = colors[BROWN];
	DrawRectangle(sx, sy+65, swidth, sheight, scolor); // bottom left
	DrawRectangle(sx + swidth + gap_turn, sy+65, swidth, sheight, scolor); // bottom right
	DrawRectangle(sx+swidth*2+gap_turn, sy+65+sheight, sheight*2, swidth-65, scolor); // right down
	DrawRectangle(sx+swidth*2+gap_turn, sy+sheight+swidth+gap_turn, sheight*2, swidth-65, scolor); // right up
	DrawRectangle(sx + swidth + gap_turn, sy+810-65, swidth, sheight, scolor); // top left
	DrawRectangle(sx, sy+810-65, swidth, sheight, scolor); // top right
	DrawRectangle(sx-sheight*2, sy+sheight+swidth+gap_turn, sheight*2, swidth-65, scolor); // left up
	DrawRectangle(sx-sheight*2, sy+65+sheight, sheight*2, swidth-65, scolor); // left down
	
	// Drawing Arena
	 gap_turn = 120;
	 sx = 20;
	 sy = 10;
	 swidth = 800/2 - gap_turn/2; // half width
	 sheight = 10;
        scolor = colors[BROWN];
	DrawRectangle(sx+65, sy+130, swidth-65, sheight, scolor); // bottom left
	DrawRectangle(sx + swidth + gap_turn, sy+130, swidth-65, sheight, scolor); // bottom right
	DrawRectangle(sx-65+swidth*2+gap_turn, sy+130+sheight, sheight*2, swidth-130, scolor); // right down
	DrawRectangle(sx-65+swidth*2+gap_turn, sy+sheight+swidth+gap_turn, sheight*2, swidth-130, scolor); // right up
	DrawRectangle(sx + swidth + gap_turn, sy+810-130, swidth-65, sheight, scolor); // top left
	DrawRectangle(sx+65, sy+810-130, swidth-65, sheight, scolor); // top right
	DrawRectangle(sx+65-sheight*2, sy+sheight+swidth+gap_turn, sheight*2, swidth-130, scolor); // left up
	DrawRectangle(sx+65-sheight*2, sy+130+sheight, sheight*2, swidth-130, scolor); // left down
	
	// Drawing Arena
	 gap_turn = 120;
	 sx = 20;
	 sy = 10;
	 swidth = 800/2 - gap_turn/2; // half width
	 sheight = 10;
	scolor = colors[BROWN];
	DrawRectangle(sx+130, sy+195, swidth-130, sheight, scolor); // bottom left
	DrawRectangle(sx + swidth + gap_turn, sy+195, swidth-130, sheight, scolor); // bottom right
	DrawRectangle(sx-130+swidth*2+gap_turn, sy+195+sheight, sheight*2, swidth-195, scolor); // right down
	DrawRectangle(sx-130+swidth*2+gap_turn, sy+sheight+swidth+gap_turn, sheight*2, swidth-195, scolor); // right up
	DrawRectangle(sx + swidth + gap_turn, sy+810-195, swidth-130, sheight, scolor); // top left
	DrawRectangle(sx+130, sy+810-195, swidth-130, sheight, scolor); // top right
	DrawRectangle(sx+130-sheight*2, sy+sheight+swidth+gap_turn, sheight*2, swidth-195, scolor); // left up
	DrawRectangle(sx+130-sheight*2, sy+195+sheight, sheight*2, swidth-195, scolor); // left down
	
	// Drawing Arena
	 gap_turn = 120;
	 sx = 20;
	 sy = 10;
	 swidth = 800/2 - gap_turn/2; // half width
	 sheight = 10;
	scolor = colors[BROWN];
	DrawRectangle(sx+195, sy+260, swidth-195, sheight, scolor); // bottom left
	DrawRectangle(sx + swidth + gap_turn, sy+260, swidth-195, sheight, scolor); // bottom right
	DrawRectangle(sx-195+swidth*2+gap_turn, sy+260+sheight, sheight*2, swidth-260, scolor); // right down
	DrawRectangle(sx-195+swidth*2+gap_turn, sy+sheight+swidth+gap_turn, sheight*2, swidth-260, scolor); // right up
	DrawRectangle(sx + swidth + gap_turn, sy+810-260, swidth-195, sheight, scolor); // top left
	DrawRectangle(sx+195, sy+810-260, swidth-195, sheight, scolor); // top right
	DrawRectangle(sx+195-sheight*2, sy+sheight+swidth+gap_turn, sheight*2, swidth-260, scolor); // left up
	DrawRectangle(sx+195-sheight*2, sy+260+sheight, sheight*2, swidth-260, scolor); // left down
	// Drawing Arena
	 gap_turn = -1;
	 sx = 20;
	 sy = 10;
	 swidth = 800/2 - gap_turn/2; // half width
	 sheight = 10;
	scolor = colors[BROWN];
	DrawRectangle(sx+260, sy+325, swidth-260, sheight, scolor); // bottom left
	DrawRectangle(sx + swidth + gap_turn, sy+325, swidth-260, sheight, scolor); // bottom right
	DrawRectangle(sx-260+swidth*2+gap_turn, sy+325+sheight, sheight*2, swidth-325, scolor); // right down
	DrawRectangle(sx-260+swidth*2+gap_turn, sy+sheight+swidth+gap_turn+12, sheight*2, swidth-325, scolor); // right up
	DrawRectangle(sx + swidth + gap_turn, sy+810-325, swidth-260, sheight, scolor); // top left
	DrawRectangle(sx+260, sy+810-325, swidth-260, sheight, scolor); // top right
	DrawRectangle(sx+260-sheight*2, sy+sheight+swidth+gap_turn+12, sheight*2, swidth-325, scolor); // left up
	DrawRectangle(sx+260-sheight*2, sy+325+sheight, sheight*2, swidth-325, scolor); // left down

	 
	DrawString(700, 800, "LIVES=",colors[MISTY_ROSE]); 
	DrawString(790, 800, to_string(LIVES),colors[MISTY_ROSE]); 
	DrawString( 50, 800, "Score=",colors[MISTY_ROSE]); 
	DrawString( 250, 800, "level=",colors[MISTY_ROSE]); 
	DrawString( 320, 800,to_string(level),colors[MISTY_ROSE]);
	DrawString( 125, 800, to_string(Score),colors[MISTY_ROSE]);
	if(Score>63&&Score<65)
	{
	 level=2;
	 for(int i=0;i<64;i++)
	 {
	   checkFlag[i] = 1;
	   }
	 }
	 if(Score>127&&Score<129)
	{
	 level=3;
	 for(int i=0;i<64;i++)
	 {
	   checkFlag[i] = 1;
	   }
	 }
	 
	 if(Score>191&&Score<193)
	{
	 level=4;
	 for(int i=0;i<64;i++)
	 {
	   checkFlag[i] = 1;
	   }
	 }
	 
	 if(level==4)
	 { 
	  // Drawing 2nd opponent car
	
	  
	float width = 8; 
	float height = 4;
	float* color = colors[BLUE_VIOLET]; 
	float radius = 4.0;
	DrawRoundRect(cx,dy,width,height,color,radius); // bottom left tyre
	DrawRoundRect(cx+width*3,dy,width,height,color,radius); // bottom right tyre
	DrawRoundRect(cx+width*3,dy+height*4,width,height,color,radius); // top right tyre
	DrawRoundRect(cx,dy+height*4,width,height,color,radius); // top left tyre
	DrawRoundRect(x, y+height*2, width, height, color, radius/2); // body left rect
	DrawRoundRect(x+width, y+height, width*2, height*3, color, radius/2); // body center rect
	DrawRoundRect(x+width*3, y+height*2, width, height, color, radius/2); // body right rect
	 
	 }
	 
	 
	Reward();
	carmove();
	Direction();

        carmove1();
        clash();
        if(LIVES<0)
        {
          gameover();
        }
        if(Score>254&&Score<257)
        {
          gamewon();
        }
    
   } 
       
void help()
    {
     glClearColor(0/*Red Component*/, 0,	//148.0/255/*Green Component*/,
			0.0/*Blue Component*/, 0 /*Alpha component*/); // Red==Green==Blue==1 --> White Colour
	glClear (GL_COLOR_BUFFER_BIT); //Update the colors
	
	DrawString( 50, 800, "Arrow key up is use to move up player car", colors[MISTY_ROSE]);
	DrawString( 50, 700, "Arrow key down is use to move down player car", colors[MISTY_ROSE]);
	DrawString( 50, 600, "Arrow key left is use to move left player car", colors[MISTY_ROSE]);
	DrawString( 50, 500, "Arrow key Right is use to move Right player car", colors[MISTY_ROSE]);
	
	}

void list()
{
 DrawString(405, 700, "press S to  Start new game",colors[MISTY_ROSE]); 
 DrawString(405, 600, "press H to show high score",colors[MISTY_ROSE]); 
 DrawString(405, 500, "press L to show help",colors[MISTY_ROSE]); 
 DrawString(405, 400, "press E to Exit game ",colors[MISTY_ROSE]); 
 }
 void screen_()
 {
   glClearColor(0/*Red Component*/, 0,	//148.0/255/*Green Component*/,
		0.0/*Blue Component*/, 0 /*Alpha component*/); // Red==Green==Blue==1 --> White Colour
	glClear (GL_COLOR_BUFFER_BIT); //Update the colors
   if(screen==true)
    {
      list();
      }
    if(screen==false&&screen1==1)  
      {
      game1();
     
       }
     else  if(screen==false&&screen1==2) 
        
      {
        help();
       }    
       
     
     glutPostRedisplay();
     }
 

void SetCanvasSize(int width, int height) {
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity();
}

 void carmove() //to move opponent car in   boundaries
 {
   if(level==1)
   {
   if (x<780 && y>=80&&y<=120)    //loop 1
   {
     x+=3;
     }
    
     else if(x>=760&&x<=800 && y<715)
     {
       y+=3;
       }
    else if(x>25 && y>=695&&y<=735)
     {
      x-=3;
      }
    else if(x>=5&&x<=45 && y<780)
      {
       y-=3;
       }
          //     
          //loop 2 
     
     else if (x<715 && y>=145&&y<=185)
    {
     x+=3;
     }     
     else if(x>=695&&x<=735 && y<650)    
     {
       y+=3;
       }
     else if(x>90 && y>=630&&y<=670)
     {
      x-=3;
      }
     else if(x>=70&&x<=110 && y>165)
      {
       y-=3;
      } 
      
             //
       //loop 3
     else if (x<650 && y>=210&&y<=250)
     {
        x+=3;
     }
      else if(x>=630&&x<=670 && y<585)
     {
       y+=3;
       }
      else if(x>155 && y>=565&&y<=605)
     {
        x-=3;
      }
      else if(x>=135&&x<=175 && y>230)
      {
       y-=3;
      } 
        // 
            // loop 4
       else if (x<585 && y>=275&&y<=315)
       {
        x+=3;
        }
        else if(x>=565&&x<=605 && y<520)
        {
          y+=3;
          }
         else if (x>220 && y>=500&&y<=540)
         {
           x-=3;
          }
         else if (x>=200&&x<=240 && y>295)
         {
          y-=3;
          } 
         
   
   
   }
    
    if(level==2||level==4)
    {
    
    if (x<780 && y>=80&&y<=120)    //loop 1
   {
     x+=5;
     }
    
     else if(x>=760&&x<=800 && y<715)
     {
       y+=5;
       }
    else if(x>25 && y>=695&&y<=735)
     {
      x-=5;
      }
    else if(x>=5&&x<=45 && y<780)
      {
       y-=5;
       }
          //     
          //loop 2 
     
     else if (x<715 && y>=145&&y<=185)
    {
     x+=5;
     }     
     else if(x>=695&&x<=735 && y<650)    
     {
       y+=5;
       }
     else if(x>90 && y>=630&&y<=670)
     {
      x-=5;
      }
     else if(x>=70&&x<=110 && y>165)
      {
       y-=5;
      } 
      
             //
       //loop 3
     else if (x<650 && y>=210&&y<=250)
     {
        x+=5;
     }
      else if(x>=630&&x<=670 && y<585)
     {
       y+=5;
       }
      else if(x>155 && y>=565&&y<=605)
     {
        x-=5;
      }
      else if(x>=135&&x<=175 && y>230)
      {
       y-=5;
      } 
        // 
            // loop 4
       else if (x<585 && y>=275&&y<=315)
       {
        x+=5;
        }
        else if(x>=565&&x<=605 && y<520)
        {
          y+=5;
          }
         else if (x>220 && y>=500&&y<=540)
         {
           x-=5;
          }
         else if (x>=200&&x<=240 && y>295)
         {
          y-=5;
          } 
         
   
    
   }
   
   
   if(level==3)
   {
   
   
   
    if (x<780 && y>=80&&y<=120)    //loop 1
   {
     x+=10;
     }
    
     else if(x>=760&&x<=800 && y<715)
     {
       y+=10;
       }
    else if(x>25 && y>=695&&y<=735)
     {
      x-=10;
      }
    else if(x>=5&&x<=45 && y<780)
      {
       y-=10;
       }
          //     
          //loop 2 
     
     else if (x<715 && y>=145&&y<=185)
    {
     x+=10;
     }     
     else if(x>=695&&x<=735 && y<650)    
     {
       y+=10;
       }
     else if(x>90 && y>=630&&y<=670)
     {
      x-=10;
      }
     else if(x>=70&&x<=110 && y>165)
      {
       y-=10;
      } 
      
             //
       //loop 3
     else if (x<650 && y>=210&&y<=250)
     {
        x+=10;
     }
      else if(x>=630&&x<=670 && y<585)
     {
       y+=10;
       }
      else if(x>155 && y>=565&&y<=605)
     {
        x-=10;
      }
      else if(x>=135&&x<=175 && y>230)
      {
       y-=10;
      } 
        // 
            // loop 4
       else if (x<585 && y>=275&&y<=315)
       {
        x+=10;
        }
        else if(x>=565&&x<=605 && y<520)
        {
          y+=10;
          }
         else if (x>220 && y>=500&&y<=540)
         {
           x-=10;
          }
         else if (x>=200&&x<=240 && y>295)
         {
          y-=10;
          } 
         
   
   
   
   
   
   
   }
      
   }
   
   void Direction()  // to move opponant  car 
   {
     if(level==1)
     {
     
       if(y>=695&&y<=735 && x>=375&&x<=415)      //1st boundary gate 3
      {
        if(wloop>oloop) 
        { 
         y=650;
         oloop=2;
         }
         }
     
     else if(y>=145&&y<=185&&x>=375&&x<=415)               //2nd boundary gate 1 
       {
        if(wloop>oloop)
        {  
         y=230;
         oloop=3;
         }
       else if(wloop<oloop)
         {
         y=100;
         oloop=1;
         }
        }
     
     //1st boundary gate 1 
        else if(y>=80&&y<=120 && x>=375&&x<=415)
        {
         if(wloop>oloop)
         {
          y=165;
          oloop=2;
          }
         }   
     
     
    
     
     else if(y>=630&&y<=670 && x>=375&&x<=415)             //2nd boundary gate 3
       {
         if(wloop>oloop) 
        {
         y=585;
         oloop=3;
         
         }
          else if(wloop<oloop)
        {   
         y=715;
         oloop=1;
         }
        }
     
     else if(y>=210&&y<=250&&x>=375&&x<=415)             //3rd boundary gate 1 
        {
          if(wloop>oloop)
         {
          y=295;
          oloop=4;
          }
          else if(wloop<oloop)
          {
           y=165;
           oloop=2;
           }
         
         }
     
     
  else if(y>=565&&x<=605 && x>=375&&x<=415)              //3rd boundary gate 3
       {
        if(wloop>oloop)
        {
         y=520;
         oloop=4;  
        }
        else if(wloop<oloop)
        {
         y=650;
         oloop=2;
         }
        }   
     
     else if(y>=275&&y<=315&&x>=375&&x<=415)             //4th boundary gate 1 out
        {
         if(wloop<oloop)
         {
          y=230;
          oloop=3;
          }
         
         }
     
     else if(y>=500&&y<=540 && x>=375&&x<=415)              //4th boundary gate 3 out
       {
        if(wloop<oloop)
        {
         y=585;
         oloop=3;
         }
        
        }
        
     
     }
      
      if(level==2||level==3||level==4)
      {
      
       if(x>=760&&x<=800 && y>=375&&y<=415)  //1st boundary gate 2
        {
        if(wloop>oloop)
        {  
          x=715;
          oloop=2;
          }
          
         }
       
         
          //
      else if(y>=695&&y<=735 && x>=375&&x<=415)      //1st boundary gate 3
      {
        if(wloop>oloop) 
        { 
         y=650;
         oloop=2;
         }
         }
       else if (x>=5&&x<=45 && y>=375&&y<=415)             //1st boundary gate 4
      {
       if(wloop>oloop)  
       {
       x=90;
       oloop=2;
       }
       } 
       
       else if(x>=70&&x<=110 && y>=375&&y<=415)               //2nd boundary gate 4
       {
         if(wloop>oloop)
         {
          x=155;
          oloop=3;
          }
          
          else if(wloop<oloop)
        { 
         x=25;
         oloop=1;
         }
         } 
         
          else if(x>=200&&x<=240 && y>=375&&y<=415)            //4th boundary gate 4 out
       {
          if(wloop<oloop)
          {
           x=155;
           oloop=3;
           }
         
         }
       
        else if(x>=135&&x<=175 && y>=375&&y<=415)            //3rd boundary gate 4
       {
         if(wloop>oloop)
         {
         x=220;
         oloop=4;
        
         }
         else if(wloop<oloop)
         {
          x=90;
          oloop=2;
          }
       }
           //1st boundary gate 1 
        else if(y>=80&&y<=120 && x>=375&&x<=415)
        {
         if(wloop>oloop)
         {
          y=165;
          oloop=2;
          }
         }   
          
       
           
      else if(y>=145&&y<=185&&x>=375&&x<=415)               //2nd boundary gate 1 
       {
        if(wloop>oloop)
        {  
         y=230;
         oloop=3;
         }
       else if(wloop<oloop)
         {
         y=100;
         oloop=1;
         }
        }
        
       else if(x>=695&&x<=735&& y>=375&&y<=415)                //2nd boundary gate 2
        {
         if(wloop>oloop) 
         {
         x=650;
         oloop=3;
         }
       else if(wloop<oloop)
       {
         x=780;
         oloop=1;
         }
         }
       else if(y>=630&&y<=670 && x>=375&&x<=415)             //2nd boundary gate 3
       {
         if(wloop>oloop) 
        {
         y=585;
         oloop=3;
         
         }
          else if(wloop<oloop)
        {   
         y=715;
         oloop=1;
         }
        }
        else if(y>=210&&y<=250&&x>=375&&x<=415)             //3rd boundary gate 1 
        {
          if(wloop>oloop)
         {
          y=295;
          oloop=4;
          }
          else if(wloop<oloop)
          {
           y=165;
           oloop=2;
           }
         
         }
         
         else if (x>=630&&x<=670 && y>=375&&y<=415)           //3rd boundary gate 2
         {
          if(wloop>oloop)
          {
           x=585;
           oloop=4;
           }
          else if(wloop<oloop)
          {
           x=715;
           oloop=2;
           }
          }  
      else if(y>=565&&x<=605 && x>=375&&x<=415)              //3rd boundary gate 3
       {
        if(wloop>oloop)
        {
         y=520;
         oloop=4;  
        }
        else if(wloop<oloop)
        {
         y=650;
         oloop=2;
         }
        }
        
      
         
         //EXTRA 4th 
         else if(y>=275&&y<=315&&x>=375&&x<=415)             //4th boundary gate 1 out
        {
         if(wloop<oloop)
         {
          y=230;
          oloop=3;
          }
         
         }
         else if (x>=565&&x<=605 && y>=375&&y<=415)           //4th boundary gate 2 out
         {
          if(wloop<oloop)
          {
          x=650;
          oloop=3;
          }  
         }
      else if(y>=500&&y<=540 && x>=375&&x<=415)              //4th boundary gate 3 out
       {
        if(wloop<oloop)
        {
         y=585;
         oloop=3;
         }
        
        }
        
      }
  
      }
    
    
    
    
//Player Car move

 void carmove1() //to move player  car in  boundary
 {
      //loop 1 player car
   if (a>25 && b==100)
   {
     a-=5;
     }
     //
   else if(a==25 && b<715)
    {
     b+=5;
    }
    else if(a<780 && b==715)
     {
      a+=5;
      }
    else if(a==780 && b>100)
      {
       b-=5;
       }
     //loop 2 player car
       
    else if (a>90 && b==165)
    {
     a-=5;
     }
     
     else if(a==90 && b<650)
     {
       b+=5;
       }
     else if(a<715 && b==650)
     {
      a+=5;
      }
      else if(a==715 && b>165)
      {
       b-=5;
      }  
      //loop 3 player car
      
      else if (a>155 && b==230)
     {
        a-=5;
     }
      else if(a==155 && b<585)
     {
       b+=5;
       }
      else if(a<650 && b==585)
     {
        a+=5;
      }
      else if(a==650 && b>230)
      {
       b-=5;
      } 
      //loop 4 player car
      
      else if (a>220 && b==295)
       {
         a-=5;
        }
      else if (a==220 && b<520)
      {
       b+=5;
       } 
       else if (a<585 && b==520)
       {
        a+=5;
        }
        else if(a==585 && b>295)
        {
          b-=5;
          }
   }



/*
 * Main Canvas drawing function.
 * */
//Board *b;
void GameDisplay()/**/{
	
        screen_();
	glutPostRedisplay();
	glutSwapBuffers(); // do not modify this line.. or draw anything below this line
}

/*This function is called (automatically) whenever any non-printable key (such as up-arrow, down-arraw)
 * is pressed from the keyboard
 *
 * You will have to add the necessary code here when the arrow keys are pressed or any other key is pressed...
 *
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 *
 * */

void NonPrintableKeys(int key, int X, int Y) {
	if (key
			== GLUT_KEY_LEFT /*GLUT_KEY_LEFT is constant and contains ASCII for left arrow key*/) {
		// what to do when left key is pressed...
		//a-=5;
		//cout<<"a "<<a<<endl;
		
		if(a==780&&b>=365&&b<=455)
		{
			 a=715;
			 wloop=2;
		cout<<"a "<<a<<endl;
		}
		      //
		else if(a==715&&b>=365&&b<=455)
		{
		         a=650;
		         wloop=3;
		cout<<"a "<<a<<endl;
		}
		      //
		else if(a==650&&b>=365&&b<=455)
		{
			    a=585;
			    wloop=4;
		cout<<"a "<<a<<endl;
		}
		      //   2nd half   
		else if(a==220&&b>=365&&b<=455)
		{
			    a=155;
			    wloop=3;
		cout<<"a "<<a<<endl;
		}
		      //
		else if(a==155&&b>=365&&b<=455)
		{
			    a=90;
			    wloop=2;
		cout<<"a "<<a<<endl;
		}
		      //
                else if(a==90&&b>=365&&b<=455)
                {
			    a=25;
			    wloop=1;
		cout<<"a "<<a<<endl;
		}
		
		      //
	} else if (key
			== GLUT_KEY_RIGHT /*GLUT_KEY_RIGHT is constant and contains ASCII for right arrow key*/) {
			//a+=5;
			//cout<<"a "<<a<<endl;
			
			if(a==25&&b>=365&&b<=455)
			{
			    a=90;
			    wloop=2;
			cout<<"a "<<a<<endl;
			}
			// 
			else if(a==90&&b>=365&&b<=455)
			{
			    a=155;
			    wloop=3;
			cout<<"a "<<a<<endl;
			}
			//
			else if(a==155&&b>=365&&b<=455)
			{
			    a=220;
			    wloop=4;
			cout<<"a "<<a<<endl;
			}
			// 2nd half
			else if(a==585&&b>=365&&b<=455)
			{
			    a=650;
			     wloop=3;
			cout<<"a "<<a<<endl;
			}
			//
			else if(a==650&&b>=365&&b<=455)
			{
			    a=715;
			     wloop=2;
			cout<<"a "<<a<<endl;
			}
			//
			else if(a==715&&b>=365&&b<=455)
			{
			    a=780;
			     wloop=1;
			cout<<"a "<<a<<endl;
			}
			
			

	} else if (key
			== GLUT_KEY_UP/*GLUT_KEY_UP is constant and contains ASCII for up arrow key*/) {
			//b+=5;
			//cout<<"b "<<b<<endl;
			
			//
	            if(b==100&&a>=365&&a<=455)
	            {
			 b=165;
			  wloop=2;
		     cout<<"b "<<b<<endl;
		    }     
		        //	
		   else if(b==165&&a>=365&&a<=455)
	            {
			 b=230;
			  wloop=3;
		     cout<<"b "<<b<<endl;
		    }   
		       //  
		   else if(b==230&&a>=365&&a<=455)
	            {
			 b=295;
			  wloop=4;
		     cout<<"b "<<b<<endl;
		    }   
		    // 2nd half
		   else if(b==520&&a>=365&&a<=455)
	            {
			 b=585;
			  wloop=3;
		     cout<<"b "<<b<<endl;
		    }    
		       //
		   else if(b==585&&a>=365&&a<=455)
	            {
			 b=650;
			  wloop=2;
		     cout<<"b "<<b<<endl;
		    }     
		       //
		   else if(b==650&&a>=365&&a<=455)
	            {
			 b=715;
			  wloop=1;
		     cout<<"b "<<b<<endl;
		    }     
	}

	else if (key
			== GLUT_KEY_DOWN/*GLUT_KEY_DOWN is constant and contains ASCII for down arrow key*/) {
                   // b-=5;
                   // cout<<"b "<<b<<endl;
                    
                     
                    if(b==715&&a>=365&&a<=455)
		  {
			 b=650;
			  wloop=2;
		     cout<<"b "<<b<<endl;
		  }
		         //
		  else if(b==650&&a>=365&&a<=455)
		  {
			 b=585;
			  wloop=3;
		     cout<<"b "<<b<<endl;
		  }
		      //
		else if(b==585&&a>=365&&a<=455)
		  {
			 b=520;
			  wloop=4;
		     cout<<"b "<<b<<endl;
		  }     
		  //2nd half
		 else if(b==295&&a>=365&&a<=455)
		  {
			 b=230;
			  wloop=3;
		     cout<<"b "<<b<<endl;
		  }  
		       //
		else if(b==230&&a>=365&&a<=455)
		  {
			 b=165;
			  wloop=2;
		     cout<<"b "<<b<<endl;
		  }          
		        //
                else if(b==165&&a>=365&&a<=455)
		  {
			 b=100;
			  wloop=1;
		     cout<<"b "<<b<<endl;
		  }    	        
		  
                   
	}

	/* This function calls the Display function to redo the drawing. Whenever you need to redraw just call
	 * this function*/

	glutPostRedisplay();

}

/*This function is called (automatically) whenever any printable key (such as x,b, enter, etc.)
 * is pressed from the keyboard
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 * */
void PrintableKeys(unsigned char key, int x, int y) {
	if (key == 27/* Escape key ASCII*/) {
		exit(1); // exit the program when escape key is pressed.
	}

	if (key == 'S' || key == 's')
			{
		          screen=false;
		           screen1=1;
		
		}
		if (key == 'l' || key == 'L')
			{
		          screen=false;
		           screen1=2;
		
		}

		
	glutPostRedisplay();
}

/*
 * This function is called after every 1000.0/FPS milliseconds
 * (FPS is defined on in the beginning).
 * You can use this function to animate objects and control the
 * speed of different moving objects by varying the constant FPS.
 *
 * */
   
    
     
void Timer(int m) {
                   x,y,a,b;
                   
        
        
       
        
        
	// implement your functionality here
      glutPostRedisplay();
      
          
       
     
	// once again we tell the library to call our Timer function after next 1000/FPS
	glutTimerFunc(1000.0, Timer, 0);
	}
     


/*This function is called (automatically) whenever your mouse moves witin inside the game window
 *
 * You will have to add the necessary code here for finding the direction of shooting
 *
 * This function has two arguments: x & y that tells the coordinate of current position of move mouse
 *
 * */
void MousePressedAndMoved(int x, int y) {
	cout << x << " " << y << endl;
	glutPostRedisplay();
}
void MouseMoved(int x, int y) {

	glutPostRedisplay();
}

/*This function is called (automatically) whenever your mouse button is clicked witin inside the game window
 *
 * You will have to add the necessary code here for shooting, etc.
 *
 * This function has four arguments: button (Left, Middle or Right), state (button is pressed or released),
 * x & y that tells the coordinate of current position of move mouse
 *
 * */
void MouseClicked(int button, int state, int x, int y) {

	if (button == GLUT_LEFT_BUTTON) // dealing only with left button
			{
		cout << GLUT_DOWN << " " << GLUT_UP << endl;

	} else if (button == GLUT_RIGHT_BUTTON) // dealing with right button
			{

	}
	glutPostRedisplay();
}
/*
 * our gateway main function
 * */
int main(int argc, char*argv[]) {

	cout<<"screen ="<<screen<<endl;
		cout<<"screen1 ="<<screen1<<endl;
	srand(time(NULL));
	//b = new Board(60, 60); // create a new board object to use in the Display Function ...

	int width = 840, height = 840; // i have set my window size to be 800 x 600
	//b->InitalizeBoard(width, height);
	InitRandomizer(); // seed the random number generator...
	glutInit(&argc, argv); // initialize the graphics library...
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
	glutInitWindowPosition(50, 50); // set the initial position of our window
	glutInitWindowSize(width, height); // set the size of our window
	glutCreateWindow("OOP Centipede"); // set the title of our game window
	SetCanvasSize(width, height); // set the number of pixels...

	// Register your functions to the library,
	// you are telling the library names of function to call for different tasks.
	//glutDisplayFunc(display); // tell library which function to call for drawing Canvas.

	glutDisplayFunc(GameDisplay); // tell library which function to call for drawing Canvas.
	glutSpecialFunc(NonPrintableKeys); // tell library which function to call for non-printable ASCII characters
	glutKeyboardFunc(PrintableKeys); // tell library which function to call for printable ASCII characters
	// This function tells the library to call our Timer function after 1000.0/FPS milliseconds...
	glutTimerFunc(1000.0, Timer, 0);

	glutMouseFunc(MouseClicked);
	glutPassiveMotionFunc(MouseMoved); // Mouse
	glutMotionFunc(MousePressedAndMoved); // Mouse

	// now handle the control to library and it will call our registered functions when
	// it deems necessary...
	glutMainLoop();
	return 1;
 }
#endif /* AsteroidS_CPP_ */
